﻿using System;
using System.Linq;

namespace CaixaEletronico
{
    class Program
    {

        static void Main(string[] args)
        {
            decimal[] notas = new decimal[] { 100, 50, 20, 10 };

            Console.WriteLine("Informe  o valor da retirada (Apenas multiplos de " + notas.Min() +"):");
            string digitacao = Console.ReadLine();


            decimal retirada = Convert.ToInt32(digitacao);
            decimal validaRetirada = retirada / notas.Min();
           

            if (validaRetirada != Convert.ToUInt16(validaRetirada))
            {     
                Console.WriteLine("Valor inválido para retirada.");
                return;
            }

            while (retirada > 0)
            {
                foreach (int item in notas)
                {
                    if ((retirada / item) >= 1)
                    {
                        Console.WriteLine("Nota de R$" + item + " entregue.");
                        retirada -= item;
                        break; 
                    }
                }
            }

            Console.WriteLine("Total da Retirada: R$" + digitacao);

        }
    }
}
